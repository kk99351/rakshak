package com.example.musictest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.musictest.databinding.ActivityOtpPageBinding;

public class OtpPage extends AppCompatActivity {
    ActivityOtpPageBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOtpPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OtpPage.this,SetPassword.class);
                startActivity(intent);
            }
        });

    }
}