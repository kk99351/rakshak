package com.example.musictest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;

import com.airbnb.lottie.LottieAnimationView;
import com.example.musictest.databinding.ActivityAnotherPageBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AnotherPage extends AppCompatActivity {

    ActivityAnotherPageBinding binding;
    DraggableFloatingActionButton sos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAnotherPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        String lat = intent.getStringExtra("CLatitude");
        String lng =intent.getStringExtra("CLongitude");

        String location = "https://www.google.com/maps?q=" + lat +","+lng+"&z=17&hl=en";

        Log.e("LAT LAT", "onCreate: "+lat);

//        AnotherPage.this.runOnUiThread(new Runnable() {
//            @Override
//            public void run() {

//                model.login("repository", "123456789").observe(AnotherPage.this, new Observer<Responses>() {
//                    @Override
//                    public void onChanged(Responses responses) {
//                        if (!responses.isError()){
//                            Log.e("True/False", "onChanged: " + responses);
//                            startService(new Intent(AnotherPage.this, MyService.class));
//                        }else {
//                            stopService(new Intent(AnotherPage.this, MyService.class));
//                        }
//                    }
//                });



//        Apis apis = ApiClient.getRetrofit().create(Apis.class);
//        Call<Responses> call = apis.login("1");
//        call.enqueue(new Callback<Responses>() {
//            @Override
//            public void onResponse(Call<Responses> call, Response<Responses> response) {
//                Responses responses1 = response.body();
//                Log.e("True/False", "onChanged: " + responses1.isError());
//                if (!responses1.isError()){
//                    AllModels models = response.body().getData();
//                    String sleep = models.getDrowsiness_status();
//                    Log.e("data", "onChanged: " +sleep);
//                    if (sleep.equals("0")){
//                        startService(new Intent(AnotherPage.this, MyService.class));
//                        binding.moveAnim.setVisibility(View.VISIBLE);
//
//                    } else if (sleep.equals("1")){
//                        startService(new Intent(AnotherPage.this, MyService2.class));
//                        binding.moveAnim.setVisibility(View.VISIBLE);
//                        binding.moveAnim.playAnimation();
//                    }else{
//                        stopService(new Intent(AnotherPage.this, MyService.class));
//                        stopService(new Intent(AnotherPage.this, MyService2.class));
//                        binding.moveAnim.pauseAnimation();
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<Responses> call, Throwable t) {
//                Log.e("TAG", "onFailure: " );
//            }
//        });
//                new Handler().postDelayed(this,100);
//            }
//        });

        binding.start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                binding.pause.setVisibility(View.VISIBLE);
                binding.stop.setVisibility(View.VISIBLE);
                binding.start.setVisibility(View.GONE);

                ui ui = new ui(100000000);
                new Thread(ui).start();
                binding.moveAnim.playAnimation();

            }

        });

        binding.pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Apis apis = ApiClient.getRetrofit().create(Apis.class);
                Call<Status> call = apis.updatedrowsinessstatus("1","2");
                call.enqueue(new Callback<Status>() {
                    @Override
                    public void onResponse(Call<Status> call, Response<Status> response) {

                    }

                    @Override
                    public void onFailure(Call<Status> call, Throwable t) {

                    }
                });

                binding.resume.setVisibility(View.VISIBLE);
                binding.pause.setVisibility(View.GONE);

                ui ui = new ui(100000000);
                new Thread(ui).interrupt();
                stopService(new Intent(AnotherPage.this, MyService.class));
                stopService(new Intent(AnotherPage.this, MyService2.class));
                binding.moveAnim.pauseAnimation();

            }
        });

        binding.resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                binding.pause.setVisibility(View.VISIBLE);
                binding.resume.setVisibility(View.GONE);

                ui ui = new ui(100000000);
                new Thread(ui).start();
                binding.moveAnim.playAnimation();

            }
        });

        binding.stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Apis apis = ApiClient.getRetrofit().create(Apis.class);
                Call<Status> call = apis.updatedrowsinessstatus("1","3");
                call.enqueue(new Callback<Status>() {
                    @Override
                    public void onResponse(Call<Status> call, Response<Status> response) {

                    }

                    @Override
                    public void onFailure(Call<Status> call, Throwable t) {

                    }
                });

                binding.pause.setVisibility(View.GONE);
                binding.stop.setVisibility(View.GONE);
                binding.resume.setVisibility(View.GONE);
                binding.start.setVisibility(View.VISIBLE);

                ui ui = new ui(100000000);
                new Thread(ui).interrupt();
                stopService(new Intent(AnotherPage.this, MyService.class));
                stopService(new Intent(AnotherPage.this, MyService2.class));
                binding.moveAnim.pauseAnimation();

            }
        });

    }

    public class ui implements Runnable{

        int sec;

        ui(int sec){
            this.sec = sec;
        }

        @Override
        public void run() {

            for (int i=0; i<sec; i++){
                try {

                    Apis apis = ApiClient.getRetrofit().create(Apis.class);
                    Call<Responses> call = apis.login("1");
                    call.enqueue(new Callback<Responses>() {
                        @Override
                        public void onResponse(Call<Responses> call, Response<Responses> response) {
                            Responses responses1 = response.body();
                            Log.e("True/False", "onChanged: " + responses1.isError());
                            if (!responses1.isError()){
                                AllModels models = response.body().getData();
                                String sleep = models.getDrowsiness_status();
                                Log.e("data", "onChanged: " +sleep);
                                if (sleep.equals("1")){
                                    startService(new Intent(AnotherPage.this, MyService.class));
                                    binding.moveAnim.setVisibility(View.VISIBLE);

                                } else{
                                    stopService(new Intent(AnotherPage.this, MyService.class));
                                    stopService(new Intent(AnotherPage.this, MyService2.class));
                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<Responses> call, Throwable t) {
                            Log.e("TAG", "onFailure: " );
                        }
                    });





                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

        }
    }
}