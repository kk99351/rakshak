package com.example.musictest;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.example.musictest.databinding.FragmentRegisterOneBinding;

public class RegisterOne extends Fragment {

    FragmentRegisterOneBinding binding;
    RadioButton radio;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        binding = binding.inflate(inflater, container, false);

        binding.pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validateEditText1(s);
            }
        });

        binding.pass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    validateEditText1(((EditText) v).getText());
                }
            }
        });

        binding.confpass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validateEditText(s);
            }
        });

        binding.confpass.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    validateEditText(((EditText) v).getText());
                }
            }
        });

        binding.group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch(i){
                    case R.id.one:
                        binding.companyid.setVisibility(View.VISIBLE);
                        break;
                    case R.id.two:
                        binding.companyid.setVisibility(View.GONE);
                        break;
                }
            }
        });

        binding.proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new RegisterTwo());
            }
        });

        return binding.getRoot();

    }

    private void validateEditText(Editable s) {
        String password = binding.pass.getText().toString();
        String confpassword = binding.confpass.getText().toString();
        if (password.equals(confpassword)) {
            binding.lconfpass.setError(null);
            // layout_confpass.setEndIconDrawable(getDrawable(R.drawable.ic_baseline_check_24));
        } else {
            binding.lconfpass.setError("Password mismatch!!");
        }

    }

    private void validateEditText1(Editable s) {
        String password1 = binding.pass.getText().toString();
        if (password1.length()>=8) {
            binding.lpass.setError(null);
            // layout_confpass.setEndIconDrawable(getDrawable(R.drawable.ic_baseline_check_24));
        } else {
            binding.lpass.setError("Password length should be 8 or more!!!");
        }


    }

    private void replaceFragment(Fragment fragment){

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }

}
