package com.example.musictest;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import com.example.musictest.databinding.FragmentRegisterTwoBinding;

public class RegisterTwo extends Fragment {

    FragmentRegisterTwoBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = binding.inflate(inflater, container, false);

        binding.three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.three.setVisibility(View.GONE);
                binding.mthree.setVisibility(View.VISIBLE);
                binding.four.setVisibility(View.VISIBLE);
            }
        });

        binding.four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.four.setVisibility(View.GONE);
                binding.mfour.setVisibility(View.VISIBLE);
                binding.five.setVisibility(View.VISIBLE);
            }
        });

        binding.five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.five.setVisibility(View.GONE);
                binding.mfive.setVisibility(View.VISIBLE);
            }
        });

        binding.submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),Login.class);
                startActivity(intent);
            }
        });

        return binding.getRoot();

       }
}