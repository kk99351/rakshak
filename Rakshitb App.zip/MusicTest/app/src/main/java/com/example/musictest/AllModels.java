package com.example.musictest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AllModels {

    @SerializedName("drowsiness_status")
    @Expose
    String drowsiness_status;

    public AllModels(String drowsiness_status) {
        this.drowsiness_status = drowsiness_status;
    }

    public String getDrowsiness_status() {
        return drowsiness_status;
    }

    public void setDrowsiness_status(String drowsiness_status) {
        this.drowsiness_status = drowsiness_status;
    }
}
